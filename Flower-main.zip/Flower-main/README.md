# Flower
This repository contains examples and tutorials for the web technologies HTML, SCSS, and JS.

### Downlode Source code from github
Using This : 

```
$ git clone https://github.com/naveen-kumawat/Flower.git
```

### Downlode Ruby 
Downlode Ruby for the SCSS
```
npm i -g scss
```

### Map SCSS file with HTML

```
Follow Youtube Video For map scss file with html
```
<a href="https://www.youtube.com/@search4code?sub_confirmation=1">
  <img src="https://static.vecteezy.com/system/resources/previews/018/930/572/non_2x/youtube-logo-youtube-icon-transparent-free-png.png" alt="YouTube Logo" width="80">
</a>

Also map js file with html file 

Project run successfully


![flower](https://user-images.githubusercontent.com/63699592/236506187-282f2dc3-cbcb-447c-81f4-63b127233ab9.png)
